angular.module('directives.crud', ['directives.crud.buttons', 'directives.crud.edit']);
